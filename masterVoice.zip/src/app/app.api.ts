export const API_MASTERVOICE = 'https://localhost:44323/api/'
export const API_CEP = 'https://api.postmon.com.br/v1/cep/' //https://api.postmon.com.br/v1/cep/*numerodoCEP*