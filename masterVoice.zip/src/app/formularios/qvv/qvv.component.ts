import { Component, OnInit, Input } from '@angular/core';
import Swal from 'sweetalert2'
import { ActivatedRoute } from '@angular/router';
import { FormularioService } from './formulario.service';
import { FormularioModel } from './formulario.model';
import * as $ from 'jquery';

@Component({
  selector: 'app-qvv',
  templateUrl: './qvv.component.html',
  styleUrls: ['./qvv.component.css']
})
export class QVVComponent implements OnInit {

  idUsr: number;
  idQuestionario: number;

  arrFormulario: FormularioModel[]
  @Input() formulario: FormularioModel

  constructor(private route: ActivatedRoute, private formularioService: FormularioService) {
    this.route.queryParams.subscribe(params => {
      this.idUsr = params['idUsr'];
      this.idQuestionario = params['idQuestionario'];
    });
  }

  ngOnInit() {
    this.formularioService.BuscaPerguntas(this.idQuestionario)
      .subscribe(arrFormulario => this.arrFormulario = arrFormulario);

    //Remoção dos Menus
    $('.sidebar').hide();
    $('.navbar').hide();
    $('.main-panel').css('width', '100%')
    $('.content').css('margin-top', '0')

  }

  EnviarRespostas() {
    Swal.fire(
      'Feito',
      'Seus dados foram enviados com sucesso!',
      'success'
    )
    //http://www4.pucsp.br/laborvox/dicas_pesquisa/downloads/QVV.pdf
  }

}
