export interface FormularioModel {
    id: number
    pergunta: string
}