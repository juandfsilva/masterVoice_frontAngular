import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QVVComponent } from './qvv.component';

describe('QVVComponent', () => {
  let component: QVVComponent;
  let fixture: ComponentFixture<QVVComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QVVComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QVVComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
