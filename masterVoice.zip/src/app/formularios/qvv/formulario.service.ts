import { FormularioModel } from './formulario.model'
import { API_MASTERVOICE } from "../../app.api";
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable'
import 'rxjs/add/operator/map'

@Injectable()
export class FormularioService {

    constructor(private http: Http) { }

    //GET
    BuscaPerguntas(idQuestionario: number): Observable<FormularioModel[]> {
        return this.http.get(`${API_MASTERVOICE}/formulario/` + idQuestionario)
            .map(response => response.json());
        //colocar catch
    }


}