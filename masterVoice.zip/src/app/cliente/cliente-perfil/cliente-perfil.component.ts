import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { stringify } from '@angular/core/src/util';
import { Alert } from 'selenium-webdriver';
import * as $ from 'jquery';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-cliente-perfil',
  templateUrl: './cliente-perfil.component.html',
  styleUrls: ['./cliente-perfil.component.css']
})
export class ClientePerfilComponent implements OnInit {
  id: number
  name: string
  idQuestionario: number

  private sub: any

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.id = +params['id']; // (+) converts string 'id' to a number
      // In a real app: dispatch action to load the details here.
    });

    console.log(this.id)
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  gerarLink() {
    let sLink = 'http://localhost:4200/QVV?idUsr=' + this.id + '&idQuestionario=' + $('#txtIdQuestionario').val()
    Swal.fire(
      'Sucesso',
      'Link gerado: <br/><a target="_blank" href="' + sLink + '">' + sLink + '</a>',
      'success'
    )
  }

  buscaCEP() {
    let retorno = {
      logradouro: 'Rua Adelino Fontoura',
      cidade: 'Santo André',
      estado: 'SP'
    }

    retorno.logradouro

    if (retorno) {
      $('#txtEndereco').val(retorno.logradouro)
      $('#txtCidade').val(retorno.cidade)
      $('#txtEstado').val(retorno.estado)
      $('#txtGrupo').focus();
    }
  }

  GravarInformacoes() {
    Swal.fire(
      'Sucesso',
      'Informações gravadas com sucesso.',
      'success'
    )
  }

}
