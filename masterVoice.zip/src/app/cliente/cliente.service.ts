import {ClienteModel} from './cliente.model'
import {API_MASTERVOICE} from "../app.api";
import {Injectable} from '@angular/core';
import {Http} from '@angular/http';
import {Observable} from 'rxjs/Observable'
import 'rxjs/add/operator/map'

@Injectable()
export class ClienteService
{

    constructor(private http: Http) { }

    //GET
    BuscarClienteUsuario(idUsuario: number): Observable<ClienteModel[]>
    {
        return this.http.get(`${API_MASTERVOICE}/cliente/buscarClientesUsuarios/` + idUsuario)
        .map(response => response.json());
        //colocar catch
    }
}