export interface ClienteModel
{
    id: number
    nome: string
    cpf: string
    nascimento: string
    sexo: string
    responsavel: string
    telefone: string
    celular: string
    endereco: string
    cidade: string
    estado: string
    idGrupo: number
    idUsuario: number
}   