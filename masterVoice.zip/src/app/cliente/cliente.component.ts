import { Component, OnInit, Input } from '@angular/core';
import { ClienteService } from './cliente.service';
import { ClienteModel } from './cliente.model';

@Component({
  selector: 'app-cliente',
  templateUrl: './cliente.component.html'
})
export class ClienteComponent implements OnInit {

   constructor(private clienteService: ClienteService) { }


   arrClientes: ClienteModel[]
   @Input() clientes: ClienteModel
  
  ngOnInit() {
    this.clienteService.BuscarClienteUsuario(1)
      .subscribe(arrClientes => this.arrClientes = arrClientes)
  }

}
