import { Component, OnInit, Input } from '@angular/core';
import { UsuarioService } from './usuarios.service';
import { UsuarioModel } from './usuarios.model';

@Component({
  selector: 'app-usuarios',
  templateUrl: './usuarios.component.html',
  styleUrls: ['./usuarios.component.css']
})
export class UsuariosComponent implements OnInit {

  constructor(private usuarioService: UsuarioService) { }

  arrUsuarios: UsuarioModel[]
  @Input() Usuarios: UsuarioModel

  ngOnInit() {
    this.usuarioService.BuscarAllUsuarios(1)
      .subscribe(arrUsuarios => this.arrUsuarios = arrUsuarios)
  }

}
