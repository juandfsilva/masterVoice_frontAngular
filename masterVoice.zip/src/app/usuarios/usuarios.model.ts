export interface UsuarioModel {
    id: number
    nome: string
    cpf: string
}   