import { UsuarioModel } from './usuarios.model'
import { API_MASTERVOICE } from "../app.api";
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable'
import 'rxjs/add/operator/map'

@Injectable()
export class UsuarioService {

    constructor(private http: Http) { }

    //GET
    BuscarAllUsuarios(idUsuario: number): Observable<UsuarioModel[]> {
        return this.http.get(`${API_MASTERVOICE}/usuario/BuscarAllUsuarios/` + idUsuario)
            .map(response => response.json());
        //colocar catch
    }
}