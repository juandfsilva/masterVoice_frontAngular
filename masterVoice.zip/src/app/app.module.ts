import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';


import { RouterModule, Routes } from '@angular/router';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { ModalModule } from 'ngx-bootstrap/modal';
import { SweetAlert2Module } from '@sweetalert2/ngx-sweetalert2';

import { AppComponent } from './app.component';
import { QVVComponent } from './formularios/qvv/qvv.component';
import { HomeComponent } from './home/home.component';
import { SobreComponent } from './sobre/sobre.component';
import { UsuariosComponent } from './usuarios/usuarios.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ClienteComponent } from './cliente/cliente.component';
import { ClienteService } from './cliente/cliente.service';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { ClientePerfilComponent } from './cliente/cliente-perfil/cliente-perfil.component';
import { FormularioService } from './formularios/qvv/formulario.service';
import { UsuarioService } from './usuarios/usuarios.service';



const appRoutes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'Home', component: HomeComponent },
  { path: 'QVV', component: QVVComponent },
  { path: 'Dashboard', component: DashboardComponent },
  { path: 'Usuarios', component: UsuariosComponent },
  { path: 'Cliente', component: ClienteComponent },
  { path: 'ClientePerfil/:id', component: ClientePerfilComponent },
  { path: 'Sobre', component: SobreComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    QVVComponent,
    HomeComponent,
    SobreComponent,
    UsuariosComponent,
    DashboardComponent,
    ClienteComponent,
    ClientePerfilComponent
  ],
  imports: [
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: true } // <-- debugging purposes only
    ),
    BrowserModule,
    AppRoutingModule,
    BsDropdownModule.forRoot(),
    TooltipModule.forRoot(),
    ModalModule.forRoot(),
    SweetAlert2Module.forRoot(),
    HttpModule,
    HttpClientModule
  ],
  providers: [
    ClienteService,
    UsuarioService,
    FormularioService
  ],
  bootstrap: [AppComponent]


})
export class AppModule { }
